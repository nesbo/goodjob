namespace Kontravers.GoodJob.Domain;

public interface IAggregate : IEntity
{
}