namespace Kontravers.GoodJob.Domain.Work;

public enum JobSourceType : byte
{
    None = 0,
    Upwork,
    Freelancer,
    Guru,
    Indeed
}