namespace Kontravers.GoodJob.Domain.Work.Services;

public enum JobProposalGeneratorType
{
    ChatGpt35Turbo
}